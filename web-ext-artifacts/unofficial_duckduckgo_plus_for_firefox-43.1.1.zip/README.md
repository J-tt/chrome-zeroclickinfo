# DuckDuckGo for WebExtension

This is the unofficial WebExtension for DuckDuckGo.

It is licensed under the terms of the Apache License, Version 2.0 (see LICENSE).
